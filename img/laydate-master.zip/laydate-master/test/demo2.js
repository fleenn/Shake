define(function(){
    'use strict';

    laydate({
        elem: '#J-xl'
    });
});